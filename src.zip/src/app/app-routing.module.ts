import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainInvoiceComponentComponent } from './main-invoice-component/main-invoice-component.component';
import { InvoiceComponentComponent } from './invoice-component/invoice-component.component';
//http://localhost:4200/invoice?id=1&active=true
const routes: Routes = [
  {path:'InvoiceMain' , component : MainInvoiceComponentComponent},
  {path:'Invoice/:id/:active' , component : InvoiceComponentComponent},
  {path:'Invoice?id=:idp&active=:activep' , component : InvoiceComponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
