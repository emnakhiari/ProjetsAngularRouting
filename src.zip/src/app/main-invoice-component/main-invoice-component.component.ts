import { Component } from '@angular/core';

@Component({
  selector: 'app-main-invoice-component',
  templateUrl: './main-invoice-component.component.html',
  styleUrls: ['./main-invoice-component.component.css']
})
export class MainInvoiceComponentComponent {

}
